package com.cognizant.collector.jirazephyr.beans;

import lombok.*;

@Data
public class MySelf {

    private String accountId;
    private String timeZone;
    private String locale;

}
