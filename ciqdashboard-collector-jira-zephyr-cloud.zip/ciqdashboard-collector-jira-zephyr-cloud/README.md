# CIQDashboard JIRA-Zephyr Collector (cloud)

### Command to Execute JAR file

    -java -jar ciqdashboard-data-collector-jirazephyr-0.0.1-SNAPSHOT.jar --spring.config.location=<PROPERTIES_FILE_PATH> 
