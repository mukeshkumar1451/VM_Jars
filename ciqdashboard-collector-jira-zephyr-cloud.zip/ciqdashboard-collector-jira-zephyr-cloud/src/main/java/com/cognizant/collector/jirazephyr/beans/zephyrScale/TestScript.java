package com.cognizant.collector.jirazephyr.beans.zephyrScale;

public class TestScript {
    private String self;

    // Getters and setters

    public String getSelf() {
        return self;
    }

    public void setSelf(String self) {
        this.self = self;
    }
}