package com.cognizant.collector.jirazephyr.beans.zephyrScale;

import lombok.Data;

@Data
public class TestExecutionStatus {
    private long id;
    private Project project;
    private String name;
    private String description;
    private int index;
    private String color;
    private boolean archived;
    private boolean isDefault;
}