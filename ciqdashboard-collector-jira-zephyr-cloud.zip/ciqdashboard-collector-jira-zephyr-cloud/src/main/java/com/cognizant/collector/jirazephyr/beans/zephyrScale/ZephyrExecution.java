package com.cognizant.collector.jirazephyr.beans.zephyrScale;

import lombok.Data;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.List;
import java.util.Map;

@Data
@Document(collection = "zephyrExecutions")
public class ZephyrExecution {

    @Id
    private String id;
    private long testCaseId;
    private String testCaseKey;
    private String testCaseName;
    private long projectId;
    private String projectKey;
    private String testCaseCreatedOn;
    private String testCaseObjective;
    private String testCasePrecondition;
    private String testCaseEstimatedTime;
    private List<String> testCaseLabels;
    private String testCaseComponent;
    private long priorityId;
    private String priorityName;
    private long statusId;
    private String statusName;
    private String testCaseFolder;
    private String testCaseOwnerSelf;
    private String testCaseOwnerAccountId;
    private String testCaseTestScriptSelf;
    private String testCaseCustomFields; // Changed to String
    private String testCaseLinksSelf;
    private List<IssueLink> testCaseIssues;
    private List<String> testCaseWebLinks;
    private String testExecutionEnvironment;
    private String testExecutionJiraProjectVersion;

    private String testExecutionKey;
    private String testExecutionStatus;
    private String testExecutionActualEndDate;
    private String testExecutionExecutionTime;
    private String testExecutionExecutedById;
    private String testExecutionAssignedToId;
    private String testExecutionComment;
    private boolean testExecutionAutomated;
    private long testCycleId;
    private String testCycleKey;
    private String testCycleName;
    private String testCycleJiraProjectVersion;
    private Status testCycleStatus;
    private String testCycleFolder;
    private String testCycleDescription;
    private String testCyclePlannedStartDate;
    private String testCyclePlannedEndDate;
    private Owner testCycleOwner;
    private String testCycleCustomFields; // Changed to String
    private Links testCycleLinks;

    // Getters and setters

    // ... (all getters and setters for the fields)
}