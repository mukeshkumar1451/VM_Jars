package com.cognizant.collector.jirazephyr.beans.zephyrScale;

import lombok.Data;

import java.util.Map;

@Data
public class TestCycle {
    private long id;
    private String key;
    private String name;
    private Project project;
    private String jiraProjectVersion;
    private Status status;
    private String folder;
    private String description;
    private String plannedStartDate;
    private String plannedEndDate;
    private Owner owner;
    private Map<String, String> customFields;
    private Links links;
}