package com.cognizant.collector.jirazephyr.client;

import com.cognizant.collector.jirazephyr.beans.zephyrScale.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import java.util.Map;

@Component
public class ZephyrClientImpl implements ZephyrClient {

    @Autowired
    private RestTemplate restTemplate;

    @Override
    public TestCaseResponse getTestCases(Map<String, String> headers, Map<String, Object> requestParams) {
        String url = "https://api.zephyrscale.smartbear.com/v2/testcases";
        return restTemplate.getForObject(url, TestCaseResponse.class, headers);
    }

    @Override
    public Priority getPriority(long id, Map<String, String> headers) {
        String url = "https://api.zephyrscale.smartbear.com/v2/priorities/" + id;
        return restTemplate.getForObject(url, Priority.class, headers);
    }

    @Override
    public Status getStatus(long id, Map<String, String> headers) {
        String url = "https://api.zephyrscale.smartbear.com/v2/statuses/" + id;
        return restTemplate.getForObject(url, Status.class, headers);
    }

    @Override
    public Project getProject(long id, Map<String, String> headers) {
        String url = "https://api.zephyrscale.smartbear.com/v2/projects/" + id;
        return restTemplate.getForObject(url, Project.class, headers);
    }

    @Override
    public TestExecutionResponse getTestExecutions(Map<String, String> headers, Map<String, Object> requestParams) {
        String url = "https://api.zephyrscale.smartbear.com/v2/testexecutions";
        return restTemplate.getForObject(url, TestExecutionResponse.class, headers);
    }
    @Override
    public TestExecutionStatus getTestExecutionStatus(long id, Map<String, String> headers) {
        String url = "https://api.zephyrscale.smartbear.com/v2/statuses/" + id;
        return restTemplate.getForObject(url, TestExecutionStatus.class, headers);
    }

    @Override
    public TestCycle getTestCycle(long id, Map<String, String> headers) {
        String url = "https://api.zephyrscale.smartbear.com/v2/testcycles/" + id;
        return restTemplate.getForObject(url, TestCycle.class, headers);
    }

}