package com.cognizant.collector.jirazephyr.beans.zephyrScale;

import lombok.Data;

import java.util.List;

@Data
public class TestExecutionResponse {
    private String next;
    private int startAt;
    private int maxResults;
    private int total;
    private boolean isLast;
    private List<TestExecution> values;

}