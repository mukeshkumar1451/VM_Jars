package com.cognizant.collector.jirazephyr.beans.zephyrScale;

import lombok.Data;

import java.util.List;
import java.util.Map;

@Data
public class TestCase {
    private long id;
    private String key;
    private String name;
    private Project project;
    private String createdOn;
    private String objective;
    private String precondition;
    private String estimatedTime;
    private List<String> labels;
    private String component;
    private Priority priority;
    private Status status;
    private String folder;
    private Owner owner;
    private TestScript testScript;
    private Map<String, String> customFields;
    private Links links;
}