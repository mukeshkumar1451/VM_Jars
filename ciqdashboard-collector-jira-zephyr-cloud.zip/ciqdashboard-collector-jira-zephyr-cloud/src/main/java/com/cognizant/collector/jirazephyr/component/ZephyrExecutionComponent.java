package com.cognizant.collector.jirazephyr.component;

import com.cognizant.collector.jirazephyr.beans.zephyrScale.*;
import com.cognizant.collector.jirazephyr.client.ZephyrClient;
import com.cognizant.collector.jirazephyr.db.repo.ZephyrExecutionRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.Map;
import java.util.stream.Collectors;

@Component
@Slf4j
public class ZephyrExecutionComponent {

    @Autowired
    ZephyrClient zephyrClient;

    @Autowired
    CommonUtilComponent commonUtilComponent;

    @Autowired
    ZephyrExecutionRepository zephyrExecutionRepository;

    public void getZephyrTests(Project project, String projectVersion) {
        Map<String, Object> requestParams = new HashMap<>();
        Map<String, String> headers = commonUtilComponent.getHeaders("/v2/testcases", requestParams);

        try {
            TestCaseResponse testCaseResponse = zephyrClient.getTestCases(headers, requestParams);
            testCaseResponse.getValues().forEach(testCase -> {
                log.info("Test Case: {}", testCase.getKey());

                Priority priority = zephyrClient.getPriority(testCase.getPriority().getId(), headers);
                log.info("Priority: {}", priority.getName());

                Status status = zephyrClient.getStatus(testCase.getStatus().getId(), headers);
                log.info("Status: {}", status.getName());

                Project projectDetails = zephyrClient.getProject(testCase.getProject().getId(), headers);
                log.info("Project: {}", projectDetails.getKey());

                TestExecutionResponse testExecutionResponse = zephyrClient.getTestExecutions(headers, requestParams);
                testExecutionResponse.getValues().forEach(testExecution -> {
                    log.info("Test Execution: {}", testExecution.getKey());

                    TestExecutionStatus testExecutionStatus = zephyrClient.getTestExecutionStatus(testExecution.getTestExecutionStatus().getId(), headers);
                    log.info("Test Execution Status: {}", testExecutionStatus.getName());

                    TestCycle testCycle = zephyrClient.getTestCycle(testExecution.getTestCycle().getId(), headers);
                    log.info("Test Cycle: {}", testCycle.getName());

                    ZephyrExecution zephyrExecution = new ZephyrExecution();
                    zephyrExecution.setTestCaseId(testCase.getId());
                    zephyrExecution.setTestCaseKey(testCase.getKey());
                    zephyrExecution.setTestCaseName(testCase.getName());
                    zephyrExecution.setProjectId(projectDetails.getId());
                    zephyrExecution.setProjectKey(projectDetails.getKey());
                    zephyrExecution.setTestCaseCreatedOn(testCase.getCreatedOn());
                    zephyrExecution.setTestCaseObjective(testCase.getObjective());
                    zephyrExecution.setTestCasePrecondition(testCase.getPrecondition());
                    zephyrExecution.setTestCaseEstimatedTime(testCase.getEstimatedTime());
                    zephyrExecution.setTestCaseLabels(testCase.getLabels());
                    zephyrExecution.setTestCaseComponent(testCase.getComponent());
                    zephyrExecution.setPriorityId(priority.getId());
                    zephyrExecution.setPriorityName(priority.getName());
                    zephyrExecution.setStatusId(status.getId());
                    zephyrExecution.setStatusName(status.getName());
                    zephyrExecution.setTestCaseFolder(testCase.getFolder());
                    zephyrExecution.setTestCaseOwnerSelf(testCase.getOwner().getSelf());
                    zephyrExecution.setTestCaseOwnerAccountId(testCase.getOwner().getAccountId());
                    zephyrExecution.setTestCaseTestScriptSelf(testCase.getTestScript().getSelf());
                    zephyrExecution.setTestCaseCustomFields(testCase.getCustomFields().entrySet().stream()
                            .map(entry -> entry.getKey() + ": " + entry.getValue())
                            .collect(Collectors.joining(", ")));
                    zephyrExecution.setTestCaseLinksSelf(testCase.getLinks().getSelf());
                    zephyrExecution.setTestCaseIssues(testCase.getLinks().getIssues());
                    zephyrExecution.setTestCaseWebLinks(testCase.getLinks().getWebLinks());
                    zephyrExecution.setTestExecutionEnvironment(testExecution.getEnvironment());
                    zephyrExecution.setTestExecutionJiraProjectVersion(testExecution.getJiraProjectVersion());
                    zephyrExecution.setTestExecutionStatus(testExecutionStatus.getName());
                    zephyrExecution.setTestExecutionActualEndDate(testExecution.getActualEndDate());
                    zephyrExecution.setTestExecutionExecutionTime(testExecution.getExecutionTime());
                    zephyrExecution.setTestExecutionExecutedById(testExecution.getExecutedById());
                    zephyrExecution.setTestExecutionAssignedToId(testExecution.getAssignedToId());
                    zephyrExecution.setTestExecutionComment(testExecution.getComment());
                    zephyrExecution.setTestExecutionAutomated(testExecution.isAutomated());
                    zephyrExecution.setTestCycleId(testCycle.getId());
                    zephyrExecution.setTestCycleKey(testCycle.getKey());
                    zephyrExecution.setTestCycleName(testCycle.getName());
                    zephyrExecution.setTestCycleJiraProjectVersion(testCycle.getJiraProjectVersion());
                    zephyrExecution.setTestCycleStatus(testCycle.getStatus());
                    zephyrExecution.setTestCycleFolder(testCycle.getFolder());
                    zephyrExecution.setTestCycleDescription(testCycle.getDescription());
                    zephyrExecution.setTestCyclePlannedStartDate(testCycle.getPlannedStartDate());
                    zephyrExecution.setTestCyclePlannedEndDate(testCycle.getPlannedEndDate());
                    zephyrExecution.setTestCycleOwner(testCycle.getOwner());
                    zephyrExecution.setTestCycleCustomFields(testCycle.getCustomFields().entrySet().stream()
                            .map(entry -> entry.getKey() + ": " + entry.getValue())
                            .collect(Collectors.joining(", ")));
                    zephyrExecution.setTestCycleLinks(testCycle.getLinks());


                    // Print collected data to the console
                    log.info("Collected Data: {}", zephyrExecution);

                    zephyrExecutionRepository.save(zephyrExecution);

                    // Process each test execution as needed
                });
            });
        } catch (Exception e) {
            log.error("Error fetching Zephyr tests", e);
        }
    }
}