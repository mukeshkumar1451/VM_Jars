package com.cognizant.collector.jirazephyr.client;

import com.cognizant.collector.jirazephyr.beans.MySelf;
import com.cognizant.collector.jirazephyr.beans.Project;
import com.cognizant.collector.jirazephyr.beans.core.JiraIssueDetails;
import com.cognizant.collector.jirazephyr.config.ProxyConfig;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;

import javax.annotation.PostConstruct;
import java.net.Authenticator;
import java.net.InetSocketAddress;
import java.net.PasswordAuthentication;
import java.net.Proxy;
import java.util.List;
import java.util.Map;

@Component
@Slf4j
public class JiraClientImpl implements JiraClient {

    @Autowired
    private ProxyConfig proxyConfig;

    private Proxy proxy;
    private RestTemplate restTemplate;

    @PostConstruct
    public void setupProxy() {
        restTemplate = new RestTemplate();
        if (proxyConfig.getProxyHost() != null && !proxyConfig.getProxyHost().isEmpty()) {
            proxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress(proxyConfig.getProxyHost(), proxyConfig.getProxyPort()));
            Authenticator.setDefault(new Authenticator() {
                @Override
                protected PasswordAuthentication getPasswordAuthentication() {
                    return new PasswordAuthentication(proxyConfig.getProxyUser(), proxyConfig.getProxyPassword().toCharArray());
                }
            });
        }
    }

    @Override
    public MySelf getMySelf() {
        try {
            String url = "https://mukeshkumar766673.atlassian.net/rest/api/latest/myself";
            HttpHeaders headers = new HttpHeaders();
            headers.setBasicAuth("mukeshkumar766673@gmail.com", "ATATT3xFfGF0Xt8kemZPX0ucL2ca4vLI2wpyIL9IrttYPp2eGK93yoSViyssVcvb4PBoxtf3Nn_4VxY-SmZHE9Xb-VMU9ynaIm-8_CAW57u3EN8kBZLh0Dyda_ubau7AHSZNUEPS2GvRDg49cbzDFaa2C7SO93cIkkk2CXorzzHW6hTGNvL1DpA=8459BF9E");
            HttpEntity<String> entity = new HttpEntity<>(headers);

            ResponseEntity<MySelf> response = restTemplate.exchange(url, HttpMethod.GET, entity, MySelf.class);
            return response.getBody();
        } catch (Exception e) {
            log.error("Error fetching MySelf data from Jira", e);
            return null;
        }
    }

    @Override
    public List<Project> getJiraProjects() {
        try {
            String url = "https://mukeshkumar766673.atlassian.net/rest/api/latest/project";
            HttpHeaders headers = new HttpHeaders();
            headers.setBasicAuth("mukeshkumar766673@gmail.com", "ATATT3xFfGF0Xt8kemZPX0ucL2ca4vLI2wpyIL9IrttYPp2eGK93yoSViyssVcvb4PBoxtf3Nn_4VxY-SmZHE9Xb-VMU9ynaIm-8_CAW57u3EN8kBZLh0Dyda_ubau7AHSZNUEPS2GvRDg49cbzDFaa2C7SO93cIkkk2CXorzzHW6hTGNvL1DpA=8459BF9E");
            HttpEntity<String> entity = new HttpEntity<>(headers);

            ResponseEntity<Project[]> response = restTemplate.exchange(url, HttpMethod.GET, entity, Project[].class);
            return List.of(response.getBody());
        } catch (Exception e) {
            log.error("Error fetching Jira projects", e);
            return null;
        }
    }

    @Override
    public JiraIssueDetails getJiraIssues(@RequestParam Map<String, String> requestParams) {
        try {
            String url = "https://mukeshkumar766673.atlassian.net/rest/api/latest/search";
            HttpHeaders headers = new HttpHeaders();
            headers.setBasicAuth("mukeshkumar766673@gmail.com", "ATATT3xFfGF0Xt8kemZPX0ucL2ca4vLI2wpyIL9IrttYPp2eGK93yoSViyssVcvb4PBoxtf3Nn_4VxY-SmZHE9Xb-VMU9ynaIm-8_CAW57u3EN8kBZLh0Dyda_ubau7AHSZNUEPS2GvRDg49cbzDFaa2C7SO93cIkkk2CXorzzHW6hTGNvL1DpA=8459BF9E");
            HttpEntity<Map<String, String>> entity = new HttpEntity<>(requestParams, headers);

            ResponseEntity<JiraIssueDetails> response = restTemplate.exchange(url, HttpMethod.GET, entity, JiraIssueDetails.class);
            return response.getBody();
        } catch (Exception e) {
            log.error("Error fetching Jira issues", e);
            return null;
        }
    }

    @Override
    public List<Map<?,?>> getProjectVersions(@PathVariable String projectId) {
        try {
            String url = "https://mukeshkumar766673.atlassian.net/rest/api/latest/project/" + projectId + "/versions";
            HttpHeaders headers = new HttpHeaders();
            headers.setBasicAuth("mukeshkumar766673@gmail.com", "ATATT3xFfGF0Xt8kemZPX0ucL2ca4vLI2wpyIL9IrttYPp2eGK93yoSViyssVcvb4PBoxtf3Nn_4VxY-SmZHE9Xb-VMU9ynaIm-8_CAW57u3EN8kBZLh0Dyda_ubau7AHSZNUEPS2GvRDg49cbzDFaa2C7SO93cIkkk2CXorzzHW6hTGNvL1DpA=8459BF9E");
            HttpEntity<String> entity = new HttpEntity<>(headers);

            ResponseEntity<Map[]> response = restTemplate.exchange(url, HttpMethod.GET, entity, Map[].class);
            return List.of(response.getBody());
        } catch (Exception e) {
            log.error("Error fetching project versions for projectId: " + projectId, e);
            return null;
        }
    }
}