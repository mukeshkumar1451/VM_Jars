package com.cognizant.collector.jirazephyr.beans.metadata;

import lombok.Data;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.time.LocalDateTime;
import java.util.Date;
@Data
@Document("scheduler_runs")
public class SchedulerInfo {
    @Id
    private String id;
    LocalDateTime lastUpdatedDate;
    private String desc;
    private String toolName;
}
