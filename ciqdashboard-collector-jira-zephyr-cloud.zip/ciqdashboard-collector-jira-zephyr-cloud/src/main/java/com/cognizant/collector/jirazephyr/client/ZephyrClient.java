package com.cognizant.collector.jirazephyr.client;


import com.cognizant.collector.jirazephyr.beans.zephyrScale.*;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.Map;

public interface ZephyrClient {

    @GetMapping("/v2/testcases")
    TestCaseResponse getTestCases(
            @RequestHeader Map<String, String> headers,
            @RequestParam Map<String, Object> requestParams
    );

    @GetMapping("/v2/priorities/{id}")
    Priority getPriority(@PathVariable("id") long id, @RequestHeader Map<String, String> headers);

    @GetMapping("/v2/statuses/{id}")
    Status getStatus(@PathVariable("id") long id, @RequestHeader Map<String, String> headers);

    @GetMapping("/v2/projects/{id}")
    Project getProject(@PathVariable("id") long id, @RequestHeader Map<String, String> headers);

    @GetMapping("/v2/testexecutions")
    TestExecutionResponse getTestExecutions(
            @RequestHeader Map<String, String> headers,
            @RequestParam Map<String, Object> requestParams
    );

    @GetMapping("/v2/statuses/{id}")
    TestExecutionStatus getTestExecutionStatus(@PathVariable("id") long id, @RequestHeader Map<String, String> headers);


    @GetMapping("/v2/testcycles/{id}")
    TestCycle getTestCycle(@PathVariable("id") long id, @RequestHeader Map<String, String> headers);
}