package com.cognizant.collector.jirazephyr.beans.zephyrScale;

public class Owner {
    private String self;
    private String accountId;

    // Getters and setters

    public String getSelf() {
        return self;
    }

    public void setSelf(String self) {
        this.self = self;
    }

    public String getAccountId() {
        return accountId;
    }

    public void setAccountId(String accountId) {
        this.accountId = accountId;
    }
}