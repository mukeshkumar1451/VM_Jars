package com.cognizant.collector.jirazephyr.beans.zephyrScale;

import lombok.Data;

import java.util.List;
import java.util.Map;

@Data
public class TestExecution {
    private long id;
    private String key;
    private Project project;
    private TestCase testCase;
    private String environment;
    private String jiraProjectVersion;
    private TestExecutionStatus testExecutionStatus;
    private String actualEndDate;
    private String estimatedTime;
    private String executionTime;
    private String executedById;
    private String assignedToId;
    private String comment;
    private boolean automated;
    private TestCycle testCycle;
    private Map<String, String> customFields;
    private Links links;

    // Getters and setters

    // ... (all getters and setters for the fields)
}