package com.cognizant.collector.jirazephyr.beans.zephyrScale;

public class Project {
    private long id;
    private long jiraProjectId;
    private String key;
    private boolean enabled;

    // Getters and setters

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public long getJiraProjectId() {
        return jiraProjectId;
    }

    public void setJiraProjectId(long jiraProjectId) {
        this.jiraProjectId = jiraProjectId;
    }

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public boolean isEnabled() {
        return enabled;
    }

    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
    }
}