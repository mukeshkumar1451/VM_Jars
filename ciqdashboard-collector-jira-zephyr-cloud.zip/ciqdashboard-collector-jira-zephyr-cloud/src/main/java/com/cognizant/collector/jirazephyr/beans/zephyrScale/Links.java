package com.cognizant.collector.jirazephyr.beans.zephyrScale;

import java.util.List;

public class Links {
    private String self;
    private List<IssueLink> issues;
    private List<String> webLinks;

    // Getters and setters

    public String getSelf() {
        return self;
    }

    public void setSelf(String self) {
        this.self = self;
    }

    public List<IssueLink> getIssues() {
        return issues;
    }

    public void setIssues(List<IssueLink> issues) {
        this.issues = issues;
    }

    public List<String> getWebLinks() {
        return webLinks;
    }

    public void setWebLinks(List<String> webLinks) {
        this.webLinks = webLinks;
    }
}