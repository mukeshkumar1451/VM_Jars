package com.cognizant.collector.jirazephyr.beans.zephyr;

import lombok.*;

@Data
public class ExecutionSummaries {

    private Object[] executionSummary;

}
