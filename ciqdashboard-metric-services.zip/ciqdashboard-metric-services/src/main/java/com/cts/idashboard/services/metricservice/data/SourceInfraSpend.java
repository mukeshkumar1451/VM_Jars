package com.cts.idashboard.services.metricservice.data;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.Date;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
@Document(collection = "source_infra_spend")
public class SourceInfraSpend {

    @Id
    private String id;
    private String infraType;
    private Date startDate;
    private Date endDate;
    private double blendedCost;
    private double unBlendedCost;
    private double usageQuantity;
}
