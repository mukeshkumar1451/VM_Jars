package com.cts.idashboard.services.metricservice.data;

public class FormulaConstants {
    public static final String countAnd="countBy";
}
