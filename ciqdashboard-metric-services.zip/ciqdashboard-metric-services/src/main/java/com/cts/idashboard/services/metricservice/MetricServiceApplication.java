package com.cts.idashboard.services.metricservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MetricServiceApplication {

    public static void main(String[] args) {
        SpringApplication.run(MetricServiceApplication.class, args);
    }


}
