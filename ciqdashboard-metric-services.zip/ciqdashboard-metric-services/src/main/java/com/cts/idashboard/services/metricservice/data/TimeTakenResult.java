package com.cts.idashboard.services.metricservice.data;

import java.util.Calendar;

import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Date;

public class TimeTakenResult {

    private long timeTaken;
    private Date created;
    private Date resolutionDate;

    public long getTimeTaken() {
        return timeTaken;
    }

    public void setTimeTaken(long timeTaken) {
        this.timeTaken = timeTaken;
    }

    public LocalDateTime getCreated() {
        return created.toInstant().atZone(ZoneId.systemDefault()).toLocalDateTime();
    }

    public void setCreated(Date created) {
        this.created = created;
    }

    public LocalDateTime getResolutionDate() {
        return resolutionDate.toInstant().atZone(ZoneId.systemDefault()).toLocalDateTime();
    }

    public void setResolutionDate(Date resolutionDate) {
        this.resolutionDate = resolutionDate;
    }

    @Override
    public String toString() {
        return "TimeTakenResult{" +
                "timeTaken=" + timeTaken +
                ", created=" + created +
                ", resolutionDate=" + resolutionDate +
                '}';
    }
}