package com.cts.idashboard.services.metricservice.data;

import lombok.Data;

@Data
public class CustomStcOutputData {

    private String calculatedDate;
    private String calculatedValue;
}
