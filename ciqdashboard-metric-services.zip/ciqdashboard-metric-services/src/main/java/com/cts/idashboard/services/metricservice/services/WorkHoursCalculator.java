package com.cts.idashboard.services.metricservice.services;

import java.time.*;
import java.time.temporal.ChronoUnit;

public class WorkHoursCalculator {
    public static final int WORK_HOURS_PER_DAY = 8;
    private static final DayOfWeek START_OF_WEEK = DayOfWeek.MONDAY;
    private static final DayOfWeek END_OF_WEEK = DayOfWeek.FRIDAY;

    public static long calculateWorkingHours(LocalDateTime start, LocalDateTime end) {
        long totalHours = 0;
        while (start.isBefore(end)) {
            // Check if the current day is a working day
            if (isWorkingDay(start)) {
                // Define working start and end time (9 AM - 5 PM assumed)
                LocalDateTime workStart = start.withHour(9).withMinute(0);
                LocalDateTime workEnd = start.withHour(17).withMinute(0);
                if (start.isBefore(workStart)) {
                    start = workStart; // Adjust to working hours
                }
                if (end.isBefore(workStart)) {
                    break; // Task finished before working hours start
                }
                if (start.isAfter(workEnd)) {
                    start = start.plusDays(1).withHour(9).withMinute(0);
                    continue; // Move to the next day
                }
                LocalDateTime effectiveEnd = end.isBefore(workEnd) ? end : workEnd;
                totalHours += ChronoUnit.HOURS.between(start, effectiveEnd);
                start = effectiveEnd.plusMinutes(1);
            } else {
                start = start.plusDays(1).withHour(9).withMinute(0);
            }
        }
        return totalHours;
    }

    private static boolean isWorkingDay(LocalDateTime date) {
        DayOfWeek dayOfWeek = date.getDayOfWeek();
        return dayOfWeek != DayOfWeek.SATURDAY && dayOfWeek != DayOfWeek.SUNDAY;
    }
}
