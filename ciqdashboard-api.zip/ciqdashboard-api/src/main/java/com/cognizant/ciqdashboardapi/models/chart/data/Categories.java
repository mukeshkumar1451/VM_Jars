package com.cognizant.ciqdashboardapi.models.chart.data;

import lombok.Data;

import java.util.ArrayList;
import java.util.List;

@Data
public class Categories {


    private List<Category> category = new ArrayList<>();



}
