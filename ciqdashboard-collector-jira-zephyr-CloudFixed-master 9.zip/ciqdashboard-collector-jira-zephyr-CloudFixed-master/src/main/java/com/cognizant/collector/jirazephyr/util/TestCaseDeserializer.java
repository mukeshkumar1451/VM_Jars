//package com.cognizant.collector.jirazephyr.util;
//
//import com.cognizant.collector.jirazephyr.beans.zephyrscale.TestCase;
//import com.fasterxml.jackson.core.JsonParser;
//import com.fasterxml.jackson.databind.DeserializationContext;
//import com.fasterxml.jackson.databind.JsonDeserializer;
//import com.fasterxml.jackson.databind.JsonNode;
//import com.fasterxml.jackson.databind.ObjectMapper;
//
//import java.io.IOException;
//import java.util.ArrayList;
//import java.util.List;
//
//public class TestCaseDeserializer extends JsonDeserializer<TestCaseDetails> {
//
//    @Override
//    public TestCaseDetails deserialize(JsonParser jsonParser, DeserializationContext deserializationContext) throws IOException {
//        ObjectMapper mapper = new ObjectMapper();
//        JsonNode node = jsonParser.getCodec().readTree(jsonParser);
//        JsonNode blocksNode=node.get("testResult").get("blocks");
//        JsonNode traceLinksNode = node.get("testResult").get("blocks").get("traceLinks");
//        List<TestCase> list=new ArrayList<>();
//        int totalcount=blocksNode.get("totalCount").asInt();
//        List<String>TestCaseList=new ArrayList<>();
//
//        /*if (traceLinksNode.isArray() && traceLinksNode.size() > 0) {
//            JsonNode firstTraceLink = traceLinksNode.get(0);
//            String testResultKey = String.valueOf(firstTraceLink.get("testResult").get("key"));
//            //System.out.println(testResultKey);
//            String testCaseKey = firstTraceLink.get("testResult").get("testCase").get("key").asText();
//            String executionDate = firstTraceLink.get("testResult").get("executionDate").asText();
//
//            // Set the values in your TestCase object
//            testCase.setTestResultKey(testResultKey);
//            testCase.setTestCaseKey(testCaseKey);
//            testCase.setExecutionDate(executionDate);
//        }*/
//        if(traceLinksNode.isArray()){
//            for(JsonNode traceLink : traceLinksNode){
//                String testResultKey = traceLink.get("testResult").get("key").asText();
//                String TestCaseKey = traceLink.get("testResult").get("testCase").get("key").asText();
//                String executionDate = traceLink.get("testResult").get("executionDate").asText();
//                String statusName=traceLink.get("testResult").get("status").get("name").asText();
//                String type=traceLink.get("type").get("name").asText();
//                TestCaseList.add(TestCaseKey);
//                TestCase testCase=new TestCase();
//
//                testCase.setTestResultKey(testResultKey);
//                testCase.setExecutionDate(executionDate);
//                //testCase.setTestCaseKey(TestCaseKey);
//                testCase.setLinkStatusName(statusName);
//                testCase.setTypeName(type);
//                list.add(testCase);
//
//            }
//        }
//        TestCaseDetails testCaseDetails = new TestCaseDetails();
//        testCaseDetails.setTestCaseKey(TestCaseList);
//        testCaseDetails.setTestCaseDetails(list);
//        testCaseDetails.setTotalCount(totalcount);
//        System.out.println(testCaseDetails);
//
//        return testCaseDetails;
//    }
//}
