package com.cognizant.collector.jirazephyr.beans.zephyrscale;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

import java.util.ArrayList;
import java.util.Date;

@JsonIgnoreProperties(ignoreUnknown = true)
@Document(collection = "#{T(com.cognizant.collector.jirazephyr.component.CommonUtilComponent).getZephyrTestCaseCollectionName()}")
@Data
public class TestCase {

    @Id
    @Field("Key")
    private String key;
    private String name;
    private String objective;
    private String precondition;
    private String estimatedTime;
    private String component;
    private String owner;

    // Project
    private int projectId;
    private String jiraProjectId;
    private Boolean enabled;

    /* Custom Fields */
//    private Object release;
//    private Object module;
//    private Object linkedUserstories;

    private String release;

    private String module;
    private String sprint;
    private String scriptName;
    private String testcaseId;
    private Date createdOn;

    private String ApplicationName;

    /* status Fields */
    public String statusName;


    /* Priority Fields */
    public String priorityName;

}
