package com.cognizant.collector.jirazephyr.beans.zephyrscale;

import com.cognizant.collector.jirazephyr.beans.Project;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class Status {

    @JsonProperty("id")
    private long statusId;

    @JsonProperty("name")
    private String statusName;

}
