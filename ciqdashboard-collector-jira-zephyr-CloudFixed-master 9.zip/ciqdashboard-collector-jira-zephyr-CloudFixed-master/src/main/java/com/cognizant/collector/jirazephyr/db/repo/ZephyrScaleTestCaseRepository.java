package com.cognizant.collector.jirazephyr.db.repo;

import com.cognizant.collector.jirazephyr.beans.zephyrscale.TestCase;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface ZephyrScaleTestCaseRepository extends MongoRepository<TestCase, String> {
}
