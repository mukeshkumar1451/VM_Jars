package com.cognizant.collector.jirazephyr.client;

import com.cognizant.collector.jirazephyr.beans.Project;
import com.cognizant.collector.jirazephyr.beans.zephyrscale.*;

import org.springframework.web.bind.annotation.*;



public interface ZephyrScaleClient {


//    @GetMapping("/v2/projects/{projectId}")
//    ProjectInfo getprojectDetails(
//           // @PathVariable("Project") String projectId,
//            @RequestHeader("Authorization") String token
//    );


//    @GetMapping("/v2/priorities")
//    PriorityInfo getPriorityDetails(
//            @RequestHeader("Authorization") String token
//    );
//
//    @GetMapping("/v2/statuses")
//    StatusInfo getStatusDetails(
//            @RequestHeader("Authorization") String token
//    );



    @GetMapping("/v2/testcases")
    TestCaseInfo getTestCases(
            @RequestHeader("Authorization") String token,
            @RequestParam("maxResults") int maxResults,
            @RequestParam("startAt") int startAt
    );

    @GetMapping("/v2/projects/{projectId}")
    Project getProject(
            @RequestHeader("Authorization") String token,
            @PathVariable("projectId") String projectId
    );

    @GetMapping("/v2/priorities/{priorityId}")
    Priority getPriority(
            @RequestHeader("Authorization") String token,
            @PathVariable("priorityId") String priorityId
    );

    @GetMapping("/v2/statuses/{statusId}")
    Status getStatus(
            @RequestHeader("Authorization") String token,
            @PathVariable("statusId") String statusId
    );

    @GetMapping("/v2/folders")
    TestCaseInfo getFolders(
            @RequestHeader("Authorization") String token,
            @RequestParam("projectKey") String projectKey,
            @RequestParam("folderType") String folderType
    );



}


