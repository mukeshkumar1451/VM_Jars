package com.cognizant.collector.jirazephyr.component;

import com.cognizant.collector.jirazephyr.beans.*;
import com.cognizant.collector.jirazephyr.client.*;
//import com.cognizant.collector.jirazephyr.beans.zephyrscale.Projects;
import lombok.extern.slf4j.*;
import org.springframework.beans.factory.annotation.*;
import org.springframework.stereotype.*;

import java.util.*;
import java.util.stream.*;

@Component
@Slf4j
public class JiraComponent {

    @Autowired
    JiraClient jiraClient;

    @Autowired
    private ZephyrScaleClient zephyrScaleClient;

    @Autowired
    JiraIssueComponent jiraIssueComponent;

    @Autowired
    ZephyrScaleTestCaseComponent zephyrScaleTestCaseComponent;


    @Value("${jiraServer.projects}")
    private String projects;

    @Value("${zephyrServer.token}")
    public String token;


    public List<Project> getProjects() {
        List<String> projectKeys = List.of(projects.split(","));
        return jiraClient.getJiraProjects().stream().filter(project -> projectKeys.contains(project.getKey())).collect(Collectors.toList());
        //return null;
    }

    public List<Map<?,?>> getProjectID(String projectId) {
        return jiraClient.getProjectID(projectId);
    }



    public void getIssues() {
      //  ZephyrScaleTestCaseComponent getZephyrScaleTestCases = new ZephyrScaleTestCaseComponent();

        getProjects().forEach(project -> {
            log.info("********* Project Name: {}", project.getId());
            jiraIssueComponent.getAllIssuesByProjectId(project);
        });

        zephyrScaleTestCaseComponent.getZephyrScaleTestCases();

    }
}
