package com.cognizant.collector.jirazephyr.beans;


public class Folder {
}
