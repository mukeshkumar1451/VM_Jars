package com.cognizant.collector.jirazephyr.component;

import com.cognizant.collector.jirazephyr.beans.Project;

//import com.cognizant.collector.jirazephyr.beans.zephyrscale.Value;
import com.cognizant.collector.jirazephyr.beans.zephyrscale.Priority;
import com.cognizant.collector.jirazephyr.beans.zephyrscale.Status;
import com.cognizant.collector.jirazephyr.beans.zephyrscale.TestCase;
import com.cognizant.collector.jirazephyr.beans.zephyrscale.TestCaseInfo;
import com.cognizant.collector.jirazephyr.client.ZephyrScaleClient;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import com.cognizant.collector.jirazephyr.service.*;
import org.springframework.beans.factory.annotation.*;
import org.springframework.util.CollectionUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.stream.Collectors;

import static com.cognizant.collector.jirazephyr.constants.Constant.PAGE_STARTS_AT;
import static com.cognizant.collector.jirazephyr.constants.Constant.RESULTS_PER_PAGE;

@Component
@Slf4j


public class ZephyrScaleTestCaseComponent {

//    private static final int RESULTS_PER_PAGE = 100; // Define the number of results per page
//    private static final int PAGE_STARTS_AT = 0; // Define the starting page
//
//    private static final String VALUES = "values"; // Define the values parameter for the ZephyrScale API
//
//    private static final Logger log = LoggerFactory.getLogger(ZephyrScaleTestCaseComponent.class);

    @Value("${zephyrServer.token}")
    public String token;

    @Value("${jiraServer.projects}")
    public String projects;

    @Autowired
    CommonUtilComponent utilComponent;

    @Autowired
    private ZephyrScaleClient zephyrScaleClient;

    @Autowired
    private ZephyrScaleTestCaseService testCaseService;

    public void getZephyrScaleTestCases() {
        System.out.println("Enterning into ZephyrScale");
        int maxResults = RESULTS_PER_PAGE;
        int startAt = PAGE_STARTS_AT;
        boolean isLast = false;
        do {
            System.out.println("Entring into Testcases");
            TestCaseInfo testCaseInfo = zephyrScaleClient.getTestCases(
                    token,
                    maxResults,
                    startAt
            );
            System.out.println("Data" + testCaseInfo);
            String[] projectKeys = projects.split(",");
            List<Integer> projectIds = new ArrayList<>();
            for(String projectKey : projectKeys){
                Project prj = zephyrScaleClient.getProject(token,projectKey);
                System.out.println("Project id" + prj.getId() );
                projectIds.add(prj.getId());
                log.info("List of Projects ******* ");
                log.info("Project Key - "+projectKey+  "  with ProjectId - " +prj.getId());
            }

            log.info("Zephyrscale test cases starting from "+startAt+" ending with "+(startAt+maxResults));

            // Collecting ZephyrScale test cases
            List<TestCase> zephyrScaleTestCases = testCaseInfo.getValues().stream().filter(testCase->projectIds.contains(testCase.getProject().getId())).map(testCase->{
                TestCase zephyrScaleTestCase = new TestCase();
                Project projectDetails = zephyrScaleClient.getProject(token, String.valueOf(testCase.getProject().getId()));
                Priority priorityDetails = zephyrScaleClient.getPriority(token, String.valueOf(testCase.getPriority().getPriorityId()));
                Status statusDetails = zephyrScaleClient.getStatus(token, String.valueOf(testCase.getStatus().getStatusId()));
                zephyrScaleTestCase.setJiraProjectId(projectDetails.getJiraProjectId());
                zephyrScaleTestCase.setProjectId(projectDetails.getId());
                zephyrScaleTestCase.setPriorityName(priorityDetails.getPriorityName());
                zephyrScaleTestCase.setStatusName(statusDetails.getStatusName());

                return testCase.getZephyrTestCase(zephyrScaleTestCase);

            }).collect(Collectors.toList());

            zephyrScaleTestCases.stream().forEach(a->System.out.println(a));
            //if (!CollectionUtils.isEmpty(zephyrScaleTestCases)) {
                startAt += maxResults;
                if (testCaseInfo.getTotal() < startAt) {
                    isLast = true;
                }
                log.info("TestCases count from server : {}", zephyrScaleTestCases.size());
                // Save processed test cases to the database
                System.out.println("data "+zephyrScaleTestCases);
                testCaseService.saveAll(zephyrScaleTestCases);
//            } else {
//                isLast = true; // If there are no test cases in the batch, we're done
//            }
        } while (!isLast);
    }


}





