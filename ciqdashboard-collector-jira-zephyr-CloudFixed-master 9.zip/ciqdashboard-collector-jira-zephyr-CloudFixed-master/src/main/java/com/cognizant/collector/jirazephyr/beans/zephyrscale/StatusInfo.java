package com.cognizant.collector.jirazephyr.beans.zephyrscale;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.util.ArrayList;
@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class StatusInfo {

    @JsonProperty("next")
    private String next;

    @JsonProperty("startAt")
    private int startAt;

    @JsonProperty("maxResults")
    private int maxResults;

    @JsonProperty("total")
    private int total;

    @JsonProperty("isLast")
    private boolean isLast;

    @JsonProperty("status")
    private ArrayList<Status> status;
}
