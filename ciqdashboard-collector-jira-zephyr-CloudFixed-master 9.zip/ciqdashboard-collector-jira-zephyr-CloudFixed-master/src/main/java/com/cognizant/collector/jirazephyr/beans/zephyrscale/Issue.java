package com.cognizant.collector.jirazephyr.beans.zephyrscale;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class Issue {
    @JsonProperty("self")
    private String self;

    @JsonProperty("issueId")
    private long issueId;

    @JsonProperty("id")
    private long id;

    @JsonProperty("target")
    private String target;

    @JsonProperty("type")
    private String type;



}

