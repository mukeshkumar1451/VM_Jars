package com.cognizant.collector.jirazephyr.beans.zephyrscale;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.util.ArrayList;
import java.util.List;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class Links {
    @JsonProperty("self")
    private String self;

    @JsonProperty("issues")
    private List<Issue> issues;

    @JsonProperty("webLinks")
    private List<String> webLinks;

}
