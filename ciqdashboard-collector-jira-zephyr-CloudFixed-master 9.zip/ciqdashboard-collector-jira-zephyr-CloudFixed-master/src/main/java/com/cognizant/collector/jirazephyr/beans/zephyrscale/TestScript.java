package com.cognizant.collector.jirazephyr.beans.zephyrscale;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class TestScript {
    @JsonProperty("self")
    private String self;

}
