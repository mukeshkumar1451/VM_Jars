package com.cognizant.collector.jirazephyr.service;

import com.cognizant.collector.jirazephyr.beans.zephyrscale.TestCase;

import com.cognizant.collector.jirazephyr.db.repo.ZephyrScaleTestCaseRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import java.util.List;
@Service
public class ZephyrScaleTestCaseService {
    @Autowired
    private ZephyrScaleTestCaseRepository repository;

    public void saveAll(List<TestCase> testCases) {
        repository.saveAll(testCases);
    }

    public List<TestCase> getAllTestCases() {
        return repository.findAll();
    }
}
