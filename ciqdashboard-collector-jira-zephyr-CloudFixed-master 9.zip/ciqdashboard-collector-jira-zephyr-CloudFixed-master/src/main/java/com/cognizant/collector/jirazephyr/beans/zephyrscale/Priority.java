package com.cognizant.collector.jirazephyr.beans.zephyrscale;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class Priority {

    @JsonProperty("id")
    private long priorityId;

    @JsonProperty("name")
    private String priorityName;

}
