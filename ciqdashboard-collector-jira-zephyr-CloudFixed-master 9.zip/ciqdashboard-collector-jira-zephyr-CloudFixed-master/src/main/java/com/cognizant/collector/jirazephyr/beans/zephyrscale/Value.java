package com.cognizant.collector.jirazephyr.beans.zephyrscale;

import com.cognizant.collector.jirazephyr.beans.Project;
import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Data;
import org.springframework.beans.BeanUtils;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Data
public class Value {

    private int id;
    private String key;
    private String name;
    private Project project;
    private Date createdOn;
    private Object objective;
    private String precondition;
    private Object estimatedTime;
    private Object component;
    private Priority priority;
    private Status status;
    private Object folder;
    private Object owner;
    private TestScript testScript;
    private CustomFields customFields;


    @JsonIgnore
    public TestCase getZephyrTestCase(TestCase testCase) {
        BeanUtils.copyProperties(this, testCase);
        testCase = this.setCustomFieldsData(testCase);
        return testCase;
    }

    @JsonIgnore
    public TestCase setCustomFieldsData(TestCase testCase) {
        if(customFields==null) return testCase;
      //  testCase.setRelease(((List)this.customFields.getRelease()).get(0));
       // testCase.setModule(((List)this.customFields.getRelease()).get(0));
      //  testCase.setLinkedUserstories(((List)this.customFields.getLinkedUserstories()).get(0));

        testCase.setRelease(this.customFields.getRelease());
        testCase.setModule(this.customFields.getModule());

        testCase.setScriptName(this.customFields.getScriptName());
        testCase.setTestcaseId(this.customFields.getTestcaseId());
        testCase.setCreatedOn(this.customFields.getCreatedOn());
        testCase.setApplicationName(this.customFields.getApplicationName());
        return testCase;
    }

}
