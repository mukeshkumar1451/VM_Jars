package com.cognizant.collector.jirazephyr.beans.zephyrscale;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.util.ArrayList;
import java.util.Date;
@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class CustomFields {


    ///need to change in Value and testcase
    @JsonProperty("release")
    private String release;

    @JsonProperty("module")
    private String module;

    @JsonProperty("sprint")
    private String sprint;

    @JsonProperty("createdOn")
    private Date createdOn;

    @JsonProperty("scriptName")
    private String scriptName;

    @JsonProperty("testCaseID")
    private String testcaseId;

    @JsonProperty("ApplicationName")
    private String ApplicationName;

//    @JsonProperty("release")
//    private Object release;
//
//    @JsonProperty("module")
//    private Object rodule;
//
//    @JsonProperty("linkedUserstories")
//    private Object linkedUserstories;
}
